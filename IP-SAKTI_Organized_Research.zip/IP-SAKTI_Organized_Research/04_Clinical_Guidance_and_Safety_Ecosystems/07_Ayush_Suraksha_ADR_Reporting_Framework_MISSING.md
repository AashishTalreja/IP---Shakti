# File 7: Ayush Suraksha ADR Reporting Framework

Gemini's research text lists this as File 7 under "Clinical Guidance & Safety Ecosystems".

A separate ADR Reporting Framework PDF was not included in the uploaded files in this batch.
The referenced e-Aushadhi PDF is File 4, not File 7.

Do not label the e-Aushadhi file as the ADR framework.
