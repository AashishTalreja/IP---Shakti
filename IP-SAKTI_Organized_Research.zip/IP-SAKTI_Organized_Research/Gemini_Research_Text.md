To feed your RAG pipeline comprehensively for the **IP-SAKTI Sahayak** project, you need to download a total of **8 foundational regulatory files**.

These files form the primary legal, regulatory, and technical source data layer required to satisfy the constraints of your **Smart India Hackathon 2026** problem statement (PS #45). [[1](https://www.pscmr.ac.in/PSCMR/sih/index.html)]

**📂 Complete Document Download Checklist & Links**

**Section 1: Core Statutory Laws & Rules (Rank 1 Evidence)**

- **File 1: The Drugs and Cosmetics Act, 1940**
  - *Purpose:* Ingest Chapter IVA (Sections 33B to 33O) to establish the primary statutory rules for ASU drugs.
  - *Download Link:* [**India Code Digital Repository**](https://indiacode.nic.in/)
- **File 2: The Drugs and Cosmetics Rules, 1945**
  - *Purpose:* Ingest Parts XVI to XIX (Rules 151 to 169) to programmatically parse rules on manufacturing licenses, Form 25-D protocols, and sample testing rules.
  - *Download Link:* [**CDSCO Official Portal**](https://cdsco.gov.in/)

**Section 2: Manufacturing & Quality Standards (Rank 1 & 2 Evidence)**

- **File 3: Schedule T (Good Manufacturing Practices) of D&C Rules**
  - *Purpose:* The fundamental blueprint detailing infrastructure, testing laboratories, storage hygiene, and quality verification audits your tool must check.
  - *Download Link:* [**Ministry of Ayush Directives**](https://www.ayush.gov.in/)
- **File 4: Comprehensive e-Aushadhi Licensing Checklist**
  - *Purpose:* Maps state vs. central authority licensing workflows, application checklists, and structural guidelines required by startups or classical manufacturers.
  - *Download Link:* [**e-Aushadhi Guidelines Portal**](https://e-aushadhi.gov.in/eaushdhi_guidelines)

**Section 3: Restriction Protocols & Guardrails (Rank 1 Evidence)**

- **File 5: The Drugs and Magic Remedies (Objectionable Advertisements) Act, 1954**
  - *Purpose:* Used to build your hard-coded regex and semantic filter models to flag forbidden advertising claims and terms.
  - *Download Link:* India Code Legislation Repository
- **File 6: Schedule J (Prohibited Disease-Cure Claims Compendium)**
  - *Purpose:* The absolute checklist of the 54 diseases/conditions that your chatbot must flatly refuse to generate promotional copy, guarantees, or public treatments for.
  - *Download Link:* Health Ministry Regulatory Archive

**Section 4: Clinical Guidance & Safety Ecosystems (Rank 2 & 3 Evidence)**

- **File 7: Ayush Suraksha ADR Reporting Framework Document**
  - *Purpose:* Ingest to mirror the official fields (System of medicine, severity of event, batch profile data) within your interactive user form layout.
  - *Download Link:* [**Ayush Suraksha Portal Reporting Form**](https://suraksha.ayush.gov.in/)
- **File 8: Pharmacopoeia Commission Quality Standards & Guidelines**
  - *Purpose:* Supplies standard naming conventions, legal plant nomenclature, and baseline purity indicators for validating Ayurvedic raw materials.
  - *Download Link:* PCIM&H Official Documents

Would you like a **bash or python download script** to automatically scrape and fetch these raw documents into a directory for your RAG engine embeddings, or do you need help drafting the **system configuration script** for parsing Schedule J conditions?

**Try without personalization**

svg

svg

svg

svg

svg

- image

  pscmr

  svg

  **PSCMR Smart Internal Hackathon 2K26**

  21 Aug 2026 — Table\_title: Problem Statements Updated on 21-Aug-2026 at 4:00 PM by SIH Table\_content: | S.No. | Organization | Problem Statement...

  image

what about ayush ncism , nch and itra acts

For a comprehensive **Smart India Hackathon (SIH) 2026** platform like **IP-SAKTI Sahayak**, adding the **NCISM**, **NCH**, and **ITRA Acts** **shifts your scope from a basic e-commerce tool to an institutional governance and standard-setting registry platform**.

Integrating these **3 vital Parliamentary Acts** expands the document count for your RAG engine dataset from **8 to 11**.

---

**🏛️ The Structural Blueprint of the 3 Acts**

```
                       ┌──────────────────────────────┐
                       │    Ministry of Ayush (MoA)   │
                       └──────────────┬───────────────┘
                                      │
       ┌──────────────────────────────┼──────────────────────────────┐
       ▼                              ▼                              ▼
 [NCISM Act, 2020]              [NCH Act, 2020]               [ITRA Act, 2020]
  • Medical Register             • Homoeopathy Register        • National Importance
  • Ethics & Rating              • Curricula Standards         • Research Benchmarks
  • National Examinations        • Institutional Rating        • Institutional Amalgamation

```

**1. The National Commission for Indian System of Medicine (NCISM) Act, 2020**

- **Status & Intent:** **Statutory Law** (Act No. 14 of 2020). It repealed the outdated Indian Medicine Central Council Act, 1970. [[1](https://prsindia.org/files/bills_acts/acts_parliament/2021/The%20National%20Commission%20for%20Indian%20System%20of%20Medicine%20\(Amendment\)%20Act,%202021.pdf), [2](https://karma.law/insights/law-library/the-national-commission-for-indian-system-of-medicine-act-2020/)]
- **Core Mandate:** Establishes the apex regulatory body governing medical education, institutional ratings, and ethical practice for **Ayurveda, Unani, Siddha, and Sowa-Rigpa (AUS&SR)** systems across India. [[1](http://ncismindia.org/), [2](https://en.wikipedia.org/wiki/National_Commission_for_Indian_System_of_Medicine)]
- **Key Pillars for Your Project:**
  - **Section 14 (National Examinations):** Mandates uniform central examinations including **NEET (UG)** for admissions, alongside the National Exit Test (NEXT) required for practitioners to enter the medical register.
  - **Autonomous Boards (Section 18):** Establishes four critical operational boards: the *Board of Ayurveda*, the *Board of Unani, Siddha, and Sowa-Rigpa*, the *Medical Assessment and Rating Board* (for college licensing), and the *Board of Ethics and Registration*.
  - **The National Register:** Legally mandates a central database of authenticated practitioners. [[1](https://neet.nta.nic.in/), [2](https://karma.law/insights/law-library/the-national-commission-for-indian-system-of-medicine-act-2020/), [3](https://en.wikipedia.org/wiki/National_Commission_for_Indian_System_of_Medicine)]

**2. The National Commission for Homoeopathy (NCH) Act, 2020**

- **Status & Intent:** **Statutory Law** (Act No. 15 of 2020). It replaced the Central Council of Homoeopathy. [[1](https://nch.org.in/), [2](https://www.indiacode.nic.in/handle/123456789/15621?locale=hi)]
- **Core Mandate:** Formulates structural rules for **Homoeopathic education, research, and professional standard compliance** symmetrically alongside NCISM. [[1](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2294220\&reg=48\&lang=1), [2](https://pmc.ncbi.nlm.nih.gov/articles/PMC12602521/)]
- **Key Pillars for Your Project:**
  - **The National Homoeopathic Register:** Mandates the tracking and public verification parameters of practitioners authorized to practice Homoeopathy in India.
  - **Quality Benchmarks:** Controls international fellowships, digital curriculum modules, and strict compliance profiles for Homoeopathic institutions. [[1](https://elms.ayush.gov.in/nchabout), [2](https://pmc.ncbi.nlm.nih.gov/articles/PMC12602521/)]

**3. The Institute of Teaching and Research in Ayurveda (ITRA) Act, 2020**

- **Status & Intent:** **Statutory Law**. [[1](https://indiacode.gov.in/act/21bfb618-b158-4641-aea3-2b67303123a1/details)]
- **Core Mandate:** Declares ITRA (located in Jamnagar, Gujarat) as an **Institution of National Importance**. It consolidated three distinct historical institutions into one centralized global center for academic and clinical research excellence. [[1](https://prsindia.org/billtrack/the-institute-of-teaching-and-research-in-ayurveda-bill-2020), [2](https://indiacode.gov.in/act/21bfb618-b158-4641-aea3-2b67303123a1/details), [3](https://www.legitquest.com/act/institute-of-teaching-and-research-in-ayurveda-act-2020/70C6)]
- **Key Pillars for Your Project:**
  - **Gold Standard Research Datasets:** ITRA functions as the baseline authority for contemporary interdisciplinary research models, clinical methodology validation, and advanced Ayurvedic pharmacological studies. Its published data should be ranked with higher structural authority than standard commercial research papers in your pipeline. [[1](https://pmc.ncbi.nlm.nih.gov/articles/PMC12602521/), [2](https://www.scribd.com/document/871675242/Brochure-Advance-Research-Methodology-and-Biostatistics-IAS-ITRA)]

---

**📂 Expansion Dataset: Additional Download Checklists**

To incorporate these acts smoothly into your pipeline, add these **3 direct legal source files** to your configuration script:

- **File 9: The National Commission for Indian System of Medicine Act, 2020**
  - *Purpose:* Supplies the foundation rules for parsing autonomous boards, National Register frameworks, and practitioner standard compliance parameters.
  - *Download Link:* [**India Code Portal**](https://www.indiacode.nic.in/handle/123456789/15621?locale=hi)
- **File 10: The National Commission for Homoeopathy Act, 2020**
  - *Purpose:* Ingested to configure structural verification logic and curriculum boundaries for Homoeopathic registries.
  - *Download Link:* [**India Code Legislation Repository**](https://indiacode.gov.in/act/10e7b056-593b-473a-95fb-7eff54bd86e7) [[1](https://elms.ayush.gov.in/nchabout)]
- **File 11: The Institute of Teaching and Research in Ayurveda Act, 2020**
  - *Purpose:* Sets the benchmark for evaluating clinical trial designs, research ethics, and institutional data modeling frameworks within the ecosystem.
  - *Download Link:* [**India Code Repository**](https://indiacode.gov.in/act/21bfb618-b158-4641-aea3-2b67303123a1/details) [[1](https://pmc.ncbi.nlm.nih.gov/articles/PMC12602521/)]

---

**⚙️ How IP-SAKTI Sahayak Can Process These Acts**

1. **The Professional Validation Module (NCISM/NCH Integration):**
   Your tool can cross-reference practitioner inputs against the framework mandated by the **Board of Ethics and Registration**. If a user searches for an active practitioner, the backend can query fields mapped directly to the statutory **National Register template** (e.g., Name, Registration ID, System, State Council status). [[1](https://karma.law/insights/law-library/the-national-commission-for-indian-system-of-medicine-act-2020/), [2](https://en.wikipedia.org/wiki/National_Commission_for_Indian_System_of_Medicine), [3](https://elms.ayush.gov.in/nchabout)]
2. **Advanced Research Evaluation Model (ITRA Integration):**
   When generating regulatory summaries for new patent and proprietary (P&P) drugs, your system can use ITRA’s operational metrics to help startups analyze whether their data methodologies match the standards expected of an *Institution of National Importance*. [[1](https://indiacode.gov.in/act/21bfb618-b158-4641-aea3-2b67303123a1/details)]

Would you like help setting up a **database schema** to structure practitioner registration data according to the **NCISM Board of Ethics guidelines**, or do y