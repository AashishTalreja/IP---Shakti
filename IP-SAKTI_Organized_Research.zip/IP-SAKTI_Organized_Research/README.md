# IP-SAKTI Sahayak: Organized Regulatory Research Set

This package organizes the uploaded documents according to the headings and file numbering used in the Gemini research text.

## Gemini's original structure

### Section 1: Core Statutory Laws & Rules
- File 1: Drugs and Cosmetics Act, 1940
- File 2: Drugs and Cosmetics Rules, 1945

### Section 2: Manufacturing & Quality Standards
- File 3: Schedule T (GMP)
- File 4: e-Aushadhi licensing checklist

### Section 3: Restriction Protocols & Guardrails
- File 5: Drugs and Magic Remedies (Objectionable Advertisements) Act, 1954
- File 6: Schedule J prohibited-claims compendium

### Section 4: Clinical Guidance & Safety Ecosystems
- File 7: Ayush Suraksha ADR reporting framework
- File 8: PCIM&H quality standards/guidelines

### Expansion Dataset
- File 9: NCISM Act, 2020
- File 10: NCH Act, 2020
- File 11: ITRA Act, 2020

## Additional uploaded documents

The remaining uploaded documents are retained rather than discarded:
- PCIM&H Scientific Advisory Board notification
- 2024 Government Analyst appointment notification
- 2020 PCIM&H re-establishment/merger resolution
- Right to Information Act, 2005

These are grouped under authority/governance or supplementary sections because they do not correspond to a separate numbered file in Gemini's 8+3 checklist.

## Important source note

The uploaded document named `7aec2088-953d-44c8-a52e-bed89d6d96eb.pdf` is the e-Aushadhi portal guideline, so it is placed under File 4.

No separate Ayush Suraksha ADR Reporting Framework PDF was among the uploaded files in this batch. The Gemini text references that framework, but this package does not fabricate or substitute a document for it.

## File-to-heading map

| Gemini heading | Number | Organized file |
|---|---:|---|
| Core Statutory Laws & Rules | 1 | `01_Drugs_and_Cosmetics_Act_and_Rules_2016.pdf` |
| Manufacturing & Quality Standards | 3 | `03_Schedule_T_GMP.pdf` |
| Manufacturing & Quality Standards | 4 | `04_e_Aushadhi_Licensing_Guidelines_Form_25D_25E.pdf` |
| Restriction Protocols & Guardrails | 5 | `05_Drugs_and_Magic_Remedies_Objectionable_Advertisements_Act_1954.pdf` |
| Restriction Protocols & Guardrails | 5-alt | `05b_Drugs_and_Magic_Remedies_Objectional_Advertisement_Act_Alternate_Copy.pdf` |
| Restriction Protocols & Guardrails | 6 | `06_Schedule_J_Prohibited_Claims_Compendium.pdf` |
| Clinical Guidance & Safety Ecosystems | 8 | `08_PCIMH_Quality_Standards_and_Guidelines.pdf` |
| Expansion Dataset | 9 | `09_NCISM_Act_2020.pdf` |
| Expansion Dataset | 10 | `10_NCH_Act_2020.pdf` |
| Expansion Dataset | 11 | `11_ITRA_Act_2020.pdf` |
| Authority Architecture | supplementary | `12_PCIMH_Scientific_Advisory_Board_2021.pdf` |
| Authority Architecture | supplementary | `13_Government_Analyst_Appointment_2024.pdf` |
| Authority Architecture | supplementary | `14_PCIMH_Reestablishment_Merger_Resolution_2020.pdf` |
| Supplementary Governance | supplementary | `15_Right_to_Information_Act_2005.pdf` |
